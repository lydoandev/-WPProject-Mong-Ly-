<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'vhcxvhpj_dreamysky' );

/** MySQL database username */
define( 'DB_USER', 'vhcxvhpj_admin' );

/** MySQL database password */
define( 'DB_PASSWORD', 'admin' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '!}bsnH}Q~VFIWH[c)qJ7(&ssD.h8C:VLN4+</9[t)(YXN]jOoS4dR>olBo#b^*82' );
define( 'SECURE_AUTH_KEY',  'n,>cn83{I=0*yr}vM<S:3kRb$cm~)rY6l(U+9IS[Y)ql7K$[+H{-l2$OR7Iy(4()' );
define( 'LOGGED_IN_KEY',    '/zxxzScqX,6b^~~qr<LAL 3)f$d%1mR(_>=FavbxXG%`hQ1Y8j:yZ8|~tZ[jO<#u' );
define( 'NONCE_KEY',        'I6<LW+U|7IXT?H$hC1OKLE<mHU>jqqxM0<4jVeTf6>}lfAY-5<+3;!f=O)/mh#fY' );
define( 'AUTH_SALT',        'ZnCCv@/ ,cX#0 %ZH`q5rMt|Rf*o[|pfyWTVjuGQ)1d5&B.;rpgK|kT=Bkd2{{D#' );
define( 'SECURE_AUTH_SALT', '7 @t]~i6]W<`P;@|E;E]l<yjadRx|Pm.jhbk%1V|M39~r|v>8Yle4]U9Uws/+o;X' );
define( 'LOGGED_IN_SALT',   'dM#^G88i i{~h{vS+b&^6.UHYzqxBI_2DwY&g~MrQ61jeO>-p&~:VH`223y-UD%:' );
define( 'NONCE_SALT',       'Wj_/P]~8r+nY7^%lntp;Q{04)o=FUjM`EAyvf$Mdq~12k^ wN|7na..*-H-vt}3G' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
define( 'WPMS_ON', true );
define( 'WPMS_SMTP_PASS', 'admin' );
